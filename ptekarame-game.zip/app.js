(()=>{
'use strict';
const TY={kata:'Tebak Kata',susun:'Susun Kata',gambar:'Tebak Gambar',hilang:'Huruf Hilang',pilih:'Pilihan Ganda',bs:'Benar atau Salah'};
const WORD=['kata','susun','gambar','hilang'];
const $=s=>document.querySelector(s);
const sl=ms=>new Promise(r=>setTimeout(r,ms));
const rnd=n=>Math.floor(Math.random()*n);
const tile=(p,s)=>'url("data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${s}" height="${s}">${p}</svg>`)+'")';
const cover=p=>'url("data:image/svg+xml,'+encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 600" preserveAspectRatio="xMidYMax slice">${p}</svg>`)+'")';
const W='fill="#fff" fill-opacity=';
const BGS=[
{n:'Abu Klasik',p:0,c:'#26272b',i:tile('<path d="M28 24v8M24 28h8" stroke="#fff" stroke-opacity=".08"/>',56),s:'56px'},
{n:'Grid Halus',p:100,c:'#242529',i:tile('<path d="M40 0H0V40" fill="none" stroke="#fff" stroke-opacity=".07"/>',40),s:'40px'},
{n:'Garis Miring',p:150,c:'#292a2e',i:tile('<path d="M0 24L24 0" stroke="#fff" stroke-opacity=".07"/>',24),s:'24px'},
{n:'Lingkaran Kaca',p:250,c:'#232427',i:cover(`<circle cx="160" cy="140" r="130" ${W}".05"/><circle cx="640" cy="200" r="190" ${W}".04"/><circle cx="420" cy="470" r="150" ${W}".06"/><circle cx="90" cy="520" r="90" ${W}".05"/>`)},
{n:'Gunung',p:350,c:'#2a2b30',i:cover(`<path d="M0 600V400L150 270L290 410L460 210L640 410L800 320V600Z" ${W}".05"/><path d="M0 600V480L200 360L380 490L580 340L800 470V600Z" ${W}".06"/>`)},
{n:'Kota Malam',p:450,c:'#202125',i:cover(`<path d="M0 600V420H70V330H150V450H210V380H300V300H380V430H460V360H550V270H640V410H720V340H800V600Z" ${W}".06"/><path d="M0 600V500H90V440H190V520H320V460H430V530H560V450H680V510H800V600Z" ${W}".05"/>`)},
{n:'Gelombang',p:600,c:'#282a2e',i:cover(`<path d="M0 420Q100 360 200 420T400 420T600 420T800 420V600H0Z" ${W}".05"/><path d="M0 500Q100 440 200 500T400 500T600 500T800 500V600H0Z" ${W}".06"/>`)}
];

function applyBg(el,b){
  el.style.backgroundColor=b.c;
  el.style.backgroundImage=b.i;
  el.style.backgroundSize=b.s||'cover';
  el.style.backgroundPosition='center bottom';
  el.style.backgroundRepeat=b.s?'repeat':'no-repeat';
}

const ITEMS=[
  {id:'wa100',d:'100 pengikut permanen',p:1000,ic:'fa-users'},
  {id:'warand',d:'Pengikut random, tidak permanen',p:750,ic:'fa-user-plus'}
];

const cv=$('#fx'),cx=cv.getContext('2d');
let P=[],run=false;
const fit=()=>{cv.width=innerWidth;cv.height=innerHeight};
fit();
addEventListener('resize',fit);

function burst(x,y,n){
  for(let i=0;i<n;i++){
    const a=Math.random()*6.283,v=3+Math.random()*7;
    P.push({x,y,vx:Math.cos(a)*v,vy:Math.sin(a)*v-4,s:4+Math.random()*5,r:Math.random()*6,vr:Math.random()*.3-.15,l:1,c:['#ffffff','#d9d9de','#b4b5bb','#8d8e95'][rnd(4)]});
  }
  if(!run){run=true;requestAnimationFrame(tick)}
}

function tick(){
  cx.clearRect(0,0,cv.width,cv.height);
  P=P.filter(p=>p.l>0);
  P.forEach(p=>{
    p.x+=p.vx;p.y+=p.vy;p.vy+=.28;p.vx*=.99;p.r+=p.vr;p.l-=.014;
    cx.save();
    cx.globalAlpha=Math.max(p.l,0);
    cx.translate(p.x,p.y);
    cx.rotate(p.r);
    cx.fillStyle=p.c;
    cx.fillRect(-p.s/2,-p.s/2,p.s,p.s);
    cx.restore();
  });
  if(P.length)requestAnimationFrame(tick);
  else{run=false;cx.clearRect(0,0,cv.width,cv.height)}
}

function fl(x,y,t){
  const d=document.createElement('div');
  d.className='float';
  d.textContent=t;
  d.style.left=x+'px';
  d.style.top=y+'px';
  document.body.appendChild(d);
  setTimeout(()=>d.remove(),1000);
}

document.addEventListener('pointerdown',e=>{
  const t=e.target.closest('.btn,.tile,.opt');
  if(!t)return;
  const r=t.getBoundingClientRect(),s=Math.max(r.width,r.height)/2,d=document.createElement('span');
  d.className='rip';
  d.style.cssText=`width:${s}px;height:${s}px;left:${e.clientX-r.left-s/2}px;top:${e.clientY-r.top-s/2}px`;
  t.appendChild(d);
  setTimeout(()=>d.remove(),600);
});

// transisi halaman roket

for(let i=0;i<14;i++){
  const m=document.createElement('i');
  m.className='mt';
  m.style.cssText=`top:${rnd(100)}%;width:${60+rnd(100)}px;animation-duration:${.6+Math.random()*.9}s;animation-delay:-${Math.random()*2}s`;
  $('#wipe').appendChild(m);
}

let busy=false;
const WP=$('#wipe'),RK=$('#rk');

let queued=false;

async function transit(label,fn,first){
  if(busy){
    if(queued)return;
    queued=true;
    while(busy)await sl(40);
    queued=false;
  }
  busy=true;
  $('#wt').textContent='Memuat '+label;
  if(!first){WP.className='in';await sl(450)}
  RK.style.left='50%';
  await sl(550);
  fn();
  await sl(150);
  RK.style.left='-20%';
  await sl(450);
  WP.className='out';
  await sl(480);
  WP.className='';
  RK.style.transition='none';
  RK.style.left='115%';
  void RK.offsetWidth;
  RK.style.transition='';
  busy=false;
}

function show(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.toggle('on',s.id===id));
}
const go=(id,label,fn)=>transit(label,()=>{if(fn)fn();show(id)});


function tw(el,to){
  const from=+el.textContent||0;
  if(from===to){el.textContent=to;return}
  let i=0;
  const iv=setInterval(()=>{i++;el.textContent=i>=12?to:Math.round(from+(to-from)/12*i);if(i>=12)clearInterval(iv)},30);
  const p=el.parentNode;
  p.classList.remove('bump');
  void p.offsetWidth;
  p.classList.add('bump');
}

function say(id,t,ok){const f=$(id);f.textContent=t;f.style.color=ok?'#8fd19e':'#e08a8a'}
function flash(el,ok){el.classList.remove('ok','bad');void el.offsetWidth;el.classList.add(ok?'ok':'bad')}

function fly(){
  const a=$('.redeem').getBoundingClientRect(),b=$('#hp').getBoundingClientRect();
  for(let i=0;i<10;i++){
    const c=document.createElement('i');
    c.className='fa-solid fa-coins fly';
    c.style.cssText=`left:${a.left+a.width/2}px;top:${a.top+a.height/2}px`;
    document.body.appendChild(c);
    setTimeout(()=>{c.style.transform=`translate(${b.left-a.left-a.width/2+rnd(20)}px,${b.top-a.top-a.height/2}px) scale(.5)`;c.style.opacity='.2'},60+i*70);
    setTimeout(()=>c.remove(),1100+i*70);
  }
}

const esc=s=>String(s).replace(/[&<>"']/g,c=>'&#'+c.charCodeAt(0)+';');
let tm=null;

function typeMsg(t){
  const b=$('#rm'),o=$('#rt');
  b.hidden=false;
  b.classList.remove('show');
  void b.offsetWidth;
  b.classList.add('show');
  o.textContent='';
  let i=0;
  clearInterval(tm);
  tm=setInterval(()=>{o.textContent=t.slice(0,++i);if(i>=t.length)clearInterval(tm)},28);
}


function spark(x,y,sel,n){
  const b=$(sel).getBoundingClientRect();
  for(let i=0;i<n;i++){
    const c=document.createElement('i');
    c.className='fa-solid fa-star fly';
    c.style.cssText=`left:${x}px;top:${y}px;font-size:1rem`;
    document.body.appendChild(c);
    setTimeout(()=>{c.style.transform=`translate(${b.left+b.width/2-x+rnd(16)-8}px,${b.top+b.height/2-y}px) scale(.4)`;c.style.opacity='.2'},40+i*60);
    setTimeout(()=>c.remove(),1000+i*60);
  }
}

function win(x,y){
  for(let i=0;i<3;i++){
    const r=document.createElement('i');
    r.className='ring';
    r.style.cssText=`left:${x}px;top:${y}px;animation-delay:${i*.12}s`;
    document.body.appendChild(r);
    setTimeout(()=>r.remove(),1100);
  }
  const q=$('#qb');
  q.classList.remove('hit');
  void q.offsetWidth;
  q.classList.add('hit');
  spark(x,y,'#hs',7);
  [$('#hs').parentNode,$('#hk')].forEach(el=>{el.classList.remove('bump');void el.offsetWidth;el.classList.add('bump')});
  if(R.st>=2){
    const c=document.createElement('div');
    c.className='combo';
    c.textContent=(R.st>=5?'Luar biasa':R.st>=3?'Hebat':'Bagus')+' x'+R.st;
    document.body.appendChild(c);
    setTimeout(()=>c.remove(),1100);
  }
}


$('#shop').addEventListener('pointermove',e=>{
  if(e.pointerType!=='mouse')return;
  const c=e.target.closest('.card');
  if(!c)return;
  const r=c.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;
  c.style.transform=`perspective(600px) rotateX(${-y*8}deg) rotateY(${x*8}deg) translateY(-4px)`;
});
$('#shop').addEventListener('pointerout',e=>{const c=e.target.closest('.card');if(c)c.style.transform=''});

['contextmenu','selectstart','copy','cut','dragstart'].forEach(n=>$('#game').addEventListener(n,e=>e.preventDefault()));
const away=v=>{if($('#game').classList.contains('on'))$('#game').classList.toggle('away',v)};
document.addEventListener('visibilitychange',()=>away(document.hidden));
addEventListener('blur',()=>away(true));
addEventListener('focus',()=>away(false));


let TID = '';
try { TID = localStorage.getItem('tr_t') || ''; } catch (e) {}

async function fpr() {
  const p = [navigator.userAgent, navigator.language, (navigator.languages || []).join(','), screen.width + 'x' + screen.height,
    screen.colorDepth, window.devicePixelRatio, navigator.hardwareConcurrency || 0, navigator.deviceMemory || 0,
    navigator.maxTouchPoints || 0, navigator.platform || '', (Intl.DateTimeFormat().resolvedOptions() || {}).timeZone || ''];
  try {
    const c = document.createElement('canvas');
    c.width = 220; c.height = 40;
    const x = c.getContext('2d');
    x.textBaseline = 'top'; x.font = '16px Arial'; x.fillStyle = '#f60'; x.fillRect(10, 5, 80, 20);
    x.fillStyle = '#069'; x.fillText('TekaRame fp 1', 12, 8);
    p.push(c.toDataURL());
    const g = document.createElement('canvas').getContext('webgl');
    const e = g && g.getExtension('WEBGL_debug_renderer_info');
    if (e) p.push(g.getParameter(e.UNMASKED_VENDOR_WEBGL), g.getParameter(e.UNMASKED_RENDERER_WEBGL));
  } catch (e) {}
  try {
    const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(p.join('|')));
    return [...new Uint8Array(h)].slice(0, 16).map(x => x.toString(16).padStart(2, '0')).join('');
  } catch (e) { return ''; }
}

let KEY = '', ST = { pts: 0, own: [0], bg: 0, ok: 0, best: 0, sq: 0 }, R = null, T = null, banned = false, pick = -1;

async function call(p, b) {
  let j = {};
  try {
    const r = await fetch('/api/' + p, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'content-type': 'application/json', 'x-tr': KEY, 'x-tr-id': TID },
      body: JSON.stringify(b || {})
    });
    j = await r.json().catch(() => ({}));
    j.status = r.status;
  } catch (e) {
    j = { err: 'net', msg: 'Jaringan bermasalah, coba lagi', status: 0 };
  }
  return j;
}

async function api(p, b) {
  let j = await call(p, b);
  if (j.status === 401 && j.need) {
    await sess(false);
    j = await call(p, b);
  }
  if (j.ban) showBan(j.ban);
  return j;
}

async function sess(first) {
  let nav = { fp: await fpr(), off: -new Date().getTimezoneOffset() };
  if (first) {
    const nt = (performance.getEntriesByType('navigation')[0] || {}).type || '';
    let fresh = false;
    try { fresh = !sessionStorage.getItem('tr_s'); sessionStorage.setItem('tr_s', '1'); } catch (e) {}
    Object.assign(nav, {
      fresh, nt, ref: !!document.referrer,
      sa: (window.matchMedia && matchMedia('(display-mode: standalone)').matches) || navigator.standalone === true
    });
  }
  const j = await call('session', { nav });
  if (j.ban) { showBan(j.ban); return j; }
  if (j.k) {
    KEY = j.k;
    if (j.t) { TID = j.t; try { localStorage.setItem('tr_t', j.t); } catch (e) {} }
    ST = { pts: j.pts, own: j.own, bg: j.bg, ok: j.ok, best: j.best, sq: j.sq };
  }
  return j;
}

function showBan(b) {
  banned = true;
  clearTimeout(T);
  R = null;
  $('#bt').textContent = b.cheat ? 'Akses ditutup' : 'Akses dibatasi';
  $('#bm2').textContent = b.cheat
    ? 'Kamu tidak bisa memainkan ini lagi karena ketahuan memakai cheat. Jika merasa ini keliru, tekan tombol ajukan.'
    : 'Akses kamu dibatasi karena pelanggaran: ' + b.label + '. Jika merasa ini keliru, tekan tombol ajukan.';
  $('#bcd').textContent = 'Kode ' + b.code;
  $('#bw').hidden = b.ap !== 0;
  $('#bap').hidden = b.ap !== 0;
  $('#bap').disabled = false;
  $('#bs').textContent = b.ap === 1 ? 'Pengajuan sudah dikirim, tunggu keputusan owner.' : b.ap === 2 ? 'Pengajuan ditolak oleh owner.' : '';
  $('#bs').style.color = '';
  show('ban');
}

$('#bap').onclick = async () => {
  const b = $('#bap');
  b.disabled = true;
  const j = await call('appeal', { why: $('#bw').value });
  if (j.ok) {
    $('#bw').hidden = true;
    b.hidden = true;
    say('#bs', 'Pengajuan terkirim. Sebutkan kode di atas ke owner.', 1);
  } else {
    b.disabled = false;
    say('#bs', j.msg || 'Gagal mengirim pengajuan, coba lagi', 0);
  }
};

$('#wok').onclick = () => go('home', 'Beranda', shop);

function shop() {
  tw($('#hp'), ST.pts);
  $('#sc').textContent = ST.ok;
  $('#sb').textContent = ST.best;
  $('#sq').textContent = ST.sq;
  const bg = BGS.map((b, i) => {
    const own = ST.own.includes(i), on = ST.bg === i;
    const lab = on ? 'Dipakai' : own ? 'Pakai' : `<i class="fa-solid fa-coins"></i>${b.p}`;
    return `<div class="card glass" style="--i:${i}"><div class="thumb" data-th="${i}"></div><b>${b.n}</b><button class="btn" data-b="${i}" ${on ? 'disabled' : ''}>${lab}</button></div>`;
  }).join('');
  const it = ITEMS.map((t, i) => `<div class="card glass" style="--i:${BGS.length + i}"><div class="thumb ic"><i class="fa-solid ${t.ic}"></i></div><b>Suntik Saluran WA</b><small class="pd">${t.d}</small><button class="btn main" data-w="${i}"><i class="fa-solid fa-coins"></i>${t.p}</button></div>`).join('');
  $('#shop').innerHTML = bg + it;
  document.querySelectorAll('[data-th]').forEach(t => applyBg(t, BGS[t.dataset.th]));
}

const shake = el => { el.style.animation = 'none'; void el.offsetWidth; el.style.animation = 'shake .4s'; };

$('#shop').addEventListener('click', async e => {
  if (!e.isTrusted) return;
  const b = e.target.closest('[data-b]'), w = e.target.closest('[data-w]');
  if (w) {
    pick = +w.dataset.w;
    const f = $('#bf');
    $('#bn').textContent = 'Suntik Saluran WA, ' + ITEMS[pick].d;
    $('#bm').textContent = '';
    f.hidden = false;
    f.style.animation = 'none';
    void f.offsetWidth;
    f.style.animation = '';
    $('#bl').focus();
    f.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    return;
  }
  if (!b || b.disabled) return;
  const i = +b.dataset.b, d = BGS[i], r = b.getBoundingClientRect(), buy = !ST.own.includes(i);
  if (buy && ST.pts < d.p) { shake(b.closest('.card')); return; }
  b.disabled = true;
  const j = await api('shop', { a: 'bg', i });
  if (j.ban) return;
  if (!j.ok) { shop(); return; }
  ST.pts = j.pts; ST.own = j.own; ST.bg = j.bg;
  if (buy) burst(r.left + r.width / 2, r.top, 40);
  applyBg($('#bg'), d);
  shop();
});

$('#bc').onclick = async e => {
  if (!e.isTrusted) return;
  const t = ITEMS[pick], l = $('#bl').value.trim(), f = $('#bf'), m = $('#bm'), c = $('#bc');
  const bad = x => { m.textContent = x; m.style.color = '#e08a8a'; shake(f); };
  if (!t) return;
  if (ST.pts < t.p) return bad('Poin belum cukup, kurang ' + (t.p - ST.pts));
  if (!/^https:\/\/(www\.)?whatsapp\.com\/channel\//i.test(l)) return bad('Masukkan link saluran WhatsApp yang benar');
  c.disabled = true;
  const j = await api('shop', { a: 'wa', i: pick, l });
  c.disabled = false;
  if (j.ban) return;
  if (!j.ok) return bad(j.msg || 'Gagal mengirim pesanan, coba lagi');
  ST.pts = j.pts;
  const r = c.getBoundingClientRect();
  burst(r.left + r.width / 2, r.top, 50);
  tw($('#hp'), ST.pts);
  $('#bl').value = '';
  m.textContent = 'Pesanan tercatat. Mengarahkan ke WhatsApp...';
  m.style.color = '#8fd19e';
  const msg = `Halo, làngzyjir_. Saya sudah menukarkan ${t.p} poin di TekaRame untuk Suntik Saluran WA (${t.d}). Link saluran saya: ${l}`;
  setTimeout(() => { location.href = 'https://wa.me/6287722625885?text=' + encodeURIComponent(msg); }, 900);
};

function result(){
  $('#rs').innerHTML=`<div class="qbox glass"><i class="fa-solid ${R.full?'fa-trophy':'fa-flag-checkered'} rtop"></i><h1 style="font-size:1.6rem">${R.life>0?'Ronde selesai':'Nyawa habis'}</h1><div class="big" style="font-size:3.4rem;margin:14px 0" id="rn">0</div><p style="opacity:.7;margin-bottom:22px">Benar ${R.right} dari ${Math.min(R.i,10)} soal, streak terbaik ${R.best}.<br>${R.full?'Semua benar, '+R.pts+' poin masuk ke saldo.':'Poin ronde ini tidak dihitung karena belum semua benar.'}</p><div style="display:flex;gap:10px;justify-content:center;flex-wrap:wrap"><button class="btn main" id="again">Main lagi</button><button class="btn" id="back">Beranda</button></div></div>`;
  $('#again').onclick=()=>play();
  $('#back').onclick=()=>go('home','Beranda',shop);
  const end=R.full?R.pts:0;
  let n=0;
  const iv=setInterval(()=>{
    n=Math.min(end,n+Math.max(1,Math.ceil((end-n)/6)));
    $('#rn').textContent=n;
    if(n>=end)clearInterval(iv);
  },45);
  if(R.full)[.2,.5,.8].forEach((f,i)=>setTimeout(()=>burst(innerWidth*f,innerHeight*.35,60),1300+i*250));
  else if(end>=50)setTimeout(()=>burst(innerWidth/2,innerHeight/3,70),1300);
}


let starting = false;

async function play() {
  if (starting) return;
  starting = true;
  $('#play').disabled = true;
  try {
    const j = await api('round', { a: 'start' });
    if (j.ban) return;
    while (busy) await sl(60);
    if (!j.rid) {
      const msg = j.msg || 'Tidak bisa memulai ronde, coba lagi';
      if ($('#home').classList.contains('on')) say('#rf', msg, 0);
      else go('home', 'Beranda', () => { shop(); say('#rf', msg, 0); });
      return;
    }
    go('game', 'Permainan', () => {
      R = { rid: j.rid, i: 0, life: j.life, pts: 0, st: 0, best: 0, right: 0, lock: false, q: null, hist: [] };
      setQ(j.q);
    });
  } finally {
    starting = false;
    $('#play').disabled = false;
  }
}

function setQ(q) {
  R.q = Object.assign({}, q, { sl: q.sl ? q.sl.slice() : null, tl: q.tl ? q.tl.map(c => ({ c, u: false })) : null, map: [], last: -1 });
  R.lock = false;
  hud();
  draw();
  timer(WORD.includes(q.t) ? 30 : 15);
}

function hud() {
  $('#hh').innerHTML = [0, 1, 2].map(i => `<i class="fa-solid fa-heart" style="opacity:${i < R.life ? 1 : .2}"></i>`).join('');
  $('#hs').textContent = R.pts;
  const k = $('#hk');
  k.style.opacity = R.st > 1 ? 1 : 0;
  k.querySelector('b').textContent = R.st;
  $('#hq').textContent = Math.min(R.i + 1, 10) + '/10';
  $('#dt').innerHTML = Array.from({ length: 10 }, (_, i) => `<i class="${R.hist[i] === 1 ? 'g' : R.hist[i] === 0 ? 'r' : i === R.i ? 'c' : ''}"></i>`).join('');
}

function draw() {
  const q = R.q, w = WORD.includes(q.t);
  let h = `<div class="meta"><span>${TY[q.t]}</span><span>${esc(q.cat)}</span></div>`;
  const A = (t, c) => `<div class="ask ${c || ''}" data-t="${esc(t)}"></div>`;
  if (q.t === 'gambar') h += `<div class="pic"><i class="fa-solid fa-${esc(q.ic)}"></i></div>` + A(`Gambar apakah ini? (${q.len} huruf)`);
  else if (q.t === 'susun') h += A(`Susun huruf menjadi satu kata.\nPetunjuk: ${q.c}`);
  else if (q.t === 'bs') h += A(q.c) + A(q.x, 'big') + A('Cocok dengan petunjuk?');
  else if (q.t === 'pilih') h += A(q.c);
  else h += A(`${q.c} (${q.len} huruf)`);
  if (w) h += `<div class="slots" id="sl"></div><div class="tiles" id="tl"></div>`;
  if (q.t === 'pilih') h += `<div class="opts">${q.o.map((o, i) => `<button class="opt" data-o="${esc(o)}"><em>${'ABCD'[i]}</em>${esc(o)}</button>`).join('')}</div>`;
  if (q.t === 'bs') h += `<div class="opts two"><button class="opt" data-o="1">Benar</button><button class="opt" data-o="0">Salah</button></div>`;
  h += `<div class="fb" id="fb"></div>`;
  $('#qb').innerHTML = h;
  if (w) paint();
}

function paint() {
  const q = R.q;
  $('#sl').innerHTML = q.sl.map((c, i) => `<button class="slot ${q.lk[i] ? 'l' : c ? 'f' : ''}${i === q.last ? ' n' : ''}" style="--i:${i}" data-s="${i}">${c}</button>`).join('');
  $('#tl').innerHTML = q.tl.map((t, i) => `<button class="tile ${t.u ? 'u' : ''}" data-k="${i}">${t.c}</button>`).join('');
}

function put(i) {
  const q = R.q, t = q.tl[i];
  if (!t || R.lock || t.u) return;
  const k = q.sl.findIndex((c, j) => !c && !q.lk[j]);
  if (k < 0) return;
  q.sl[k] = t.c;
  t.u = true;
  q.map[k] = i;
  q.last = k;
  paint();
  if (q.sl.every(c => c)) judge(q.sl.join(''));
}

function pull(k) {
  const q = R.q;
  if (R.lock || q.lk[k] || !q.sl[k]) return;
  q.tl[q.map[k]].u = false;
  q.sl[k] = '';
  q.last = -1;
  paint();
}

$('#qb').addEventListener('click', e => {
  if (!e.isTrusted) return;
  const t = e.target.closest('[data-k],[data-s],[data-o]');
  if (!t || !R || R.lock) return;
  if (t.dataset.k !== undefined) put(+t.dataset.k);
  else if (t.dataset.s !== undefined) pull(+t.dataset.s);
  else judge(t.dataset.o, t);
});

addEventListener('keydown', e => {
  if (!e.isTrusted || !R || !R.q || R.lock || !$('#game').classList.contains('on') || !WORD.includes(R.q.t)) return;
  const q = R.q;
  if (e.key === 'Backspace') {
    for (let k = q.sl.length - 1; k >= 0; k--) if (q.sl[k] && !q.lk[k]) { pull(k); break; }
  } else if (/^[a-z]$/i.test(e.key)) {
    const i = q.tl.findIndex(t => !t.u && t.c === e.key.toUpperCase());
    if (i >= 0) put(i);
  }
});

function timer(s) {
  const b = $('#tb');
  b.style.transition = 'none';
  b.style.width = '100%';
  void b.offsetWidth;
  b.style.transition = `width ${s}s linear`;
  b.style.width = '0%';
  clearTimeout(T);
  T = setTimeout(() => judge(''), s * 1000);
}

async function judge(v, el) {
  if (!R || R.lock) return;
  R.lock = true;
  clearTimeout(T);
  const b = $('#tb'), wd = getComputedStyle(b).width;
  b.style.transition = 'none';
  b.style.width = wd;
  const q = R.q, tg = el || $('#sl') || $('#qb');
  if (el) el.classList.add('sel');
  const j = await api('round', { a: 'ans', rid: R.rid, qi: R.i, v });
  if (j.ban) return;
  if (j.ok === undefined) {
    R = null;
    go('home', 'Beranda', () => { shop(); say('#rf', j.msg || 'Ronde dibatalkan, coba lagi', 0); });
    return;
  }
  const r = tg.getBoundingClientRect(), x = r.left + r.width / 2, y = r.top, ok = j.ok;
  R.hist[R.i] = ok ? 1 : 0;
  R.pts = j.pts; R.st = j.st; R.life = j.life; R.best = j.best; R.right = j.right;
  tg.classList.add(ok ? 'ok' : 'bad');
  if (ok) {
    fl(x, y, '+10');
    burst(x, y + 20, R.st > 2 ? 60 : 30);
    win(x, y);
    $('#fb').textContent = ['Mantap', 'Keren', 'Tepat', 'Sempurna'][rnd(4)];
  } else {
    $('#fb').textContent = 'Jawaban: ' + j.rev;
  }
  if (q.t === 'pilih' || q.t === 'bs') {
    document.querySelectorAll('.opt').forEach(o => {
      const c = ok ? o === el : (q.t === 'bs' ? o.dataset.o === (j.rev === 'Benar' ? '1' : '0') : o.dataset.o === j.rev);
      if (c) o.classList.add('ok');
    });
  }
  hud();
  if (j.done) {
    R.res = j;
    setTimeout(finish, ok ? 1000 : 1600);
  } else {
    setTimeout(() => { if (!R) return; R.i = j.i; setQ(j.q); }, ok ? 1000 : 1600);
  }
}

function finish() {
  if (!R) return;
  clearTimeout(T);
  const j = R.res;
  R.full = !!j.full;
  R.i = j.i;
  ST.pts = j.total; ST.ok = j.okAll; ST.best = j.bestAll;
  go('result', 'Hasil', result);
}

$('#play').onclick = e => { if (e.isTrusted) play(); };
$('#quit').onclick = () => { clearTimeout(T); R = null; go('home', 'Beranda', shop); };

for (let i = 0; i < 9; i++) {
  const o = document.createElement('i'), s = 60 + rnd(180);
  o.className = 'orb';
  o.style.cssText = `width:${s}px;height:${s}px;left:${rnd(100)}%;top:${rnd(100)}%;border-radius:${i % 3 ? '50%' : '28%'};animation-duration:${18 + rnd(18)}s;animation-delay:-${rnd(30)}s;${i % 2 ? 'border:1px solid rgba(255,255,255,.1)' : 'background:rgba(255,255,255,.035)'}`;
  $('#bg').appendChild(o);
}

async function redeem() {
  const bar = $('.redeem'), k = $('#rc').value.trim();
  $('#rm').hidden = true;
  if (!k) { say('#rf', 'Masukkan kode dulu', 0); flash(bar, 0); return; }
  const j = await api('redeem', { code: k });
  if (j.ban) return;
  if (!j.ok) { say('#rf', j.msg || 'Gagal menukar kode', 0); flash(bar, 0); return; }
  $('#rc').value = '';
  say('#rf', j.t === 'm' ? 'Kode berhasil ditukar' : '+' + j.n + ' poin masuk', 1);
  flash(bar, 1);
  const r = bar.getBoundingClientRect();
  burst(r.left + r.width / 2, r.top + r.height / 2, 40);
  if (j.t === 'm') typeMsg(j.x);
  else { ST.pts = j.pts; fly(); }
  setTimeout(shop, 900);
}

$('#rb').onclick = e => { if (e.isTrusted) redeem(); };
$('#rc').addEventListener('keydown', e => { if (e.key === 'Enter' && e.isTrusted) redeem(); });

(async () => {
  applyBg($('#bg'), BGS[0]);
  const j = await sess(true);
  if (j.k) {
    applyBg($('#bg'), BGS[ST.bg] || BGS[0]);
    shop();
    $('#hn').textContent = ST.sq + ' soal campuran. Jawab 10 soal benar semua untuk mendapat poin ronde.';
  } else if (!banned) {
    shop();
    $('#hn').textContent = 'Server belum merespons (kode ' + (j.status || 'jaringan') + '). Cek deploy dan environment variables.';
  }
  transit('Beranda', () => show(banned ? 'ban' : j.warn ? 'warn' : 'home'), true);
})();

})();
