const crypto = require('crypto');
const L = require('./_lib');
const { E, SPEC } = require('./_data');

const WORD = ['kata', 'susun', 'gambar', 'hilang'];
const LET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
const rnd = n => Math.floor(Math.random() * n);
const shuf = a => {
  a = a.slice();
  for (let i = a.length - 1; i > 0; i--) { const j = rnd(i + 1); [a[i], a[j]] = [a[j], a[i]]; }
  return a;
};
const isTrue = (id, i) => crypto.createHmac('sha256', process.env.TR_SECRET || '').update(id + ':' + i).digest()[0] % 2 === 0;

function mkq(id, i, si) {
  const [ei, t] = SPEC[si], e = E[ei];
  const q = { t, cat: e.cat, len: e.a.length };
  const same = E.filter(x => x.cat === e.cat && x !== e);
  if (t !== 'gambar') q.c = e.c;
  if (t === 'gambar') q.ic = e.ic;
  if (t === 'pilih') q.o = shuf([e, ...shuf(same).slice(0, 3)]).map(x => x.a);
  if (t === 'bs') q.x = isTrue(id, i) ? e.a : same[rnd(same.length)].a;
  if (WORD.includes(t)) {
    const n = e.a.length, lk = Array(n).fill(false);
    if (t === 'hilang') {
      let k = Math.max(1, Math.round(n * 0.4));
      while (n - k < 2) k--;
      shuf([...Array(n).keys()]).slice(0, k).forEach(x => { lk[x] = true; });
    }
    const need = e.a.split('').filter((ch, x) => !lk[x]);
    const ex = t === 'susun' ? [] : Array.from({ length: 3 }, () => LET[rnd(26)]);
    q.lk = lk;
    q.sl = e.a.split('').map((ch, x) => (lk[x] ? ch : ''));
    q.tl = shuf(need.concat(ex));
  }
  return q;
}

function correct(id, i, si, v) {
  const [ei, t] = SPEC[si];
  if (t === 'bs') return String(v) === (isTrue(id, i) ? '1' : '0');
  return String(v).toUpperCase() === E[ei].a;
}

function bot(tm, total, full) {
  const fast = tm.filter(x => x < 500).length;
  if (fast >= 3) return 'jawaban terlalu cepat x' + fast;
  if (tm.length >= 6) {
    const m = tm.reduce((a, b) => a + b, 0) / tm.length;
    const sd = Math.sqrt(tm.reduce((a, b) => a + (b - m) * (b - m), 0) / tm.length);
    if (sd < 80 && m < 4000) return 'interval jawaban seragam sd=' + Math.round(sd);
  }
  if (full && total < 15000) return 'ronde selesai terlalu cepat ' + total + 'ms';
  return '';
}

async function start(c, res) {
  const { pid, p, d, t } = c;
  if (!(await L.rl('rs' + pid, 30, 3600000))) {
    const b = await L.strike(c, 'AUTOPLAY', 1, 'ronde dimulai terlalu sering');
    if (b) return L.deny(res, b);
    return res.status(429).json({ err: 'lim', msg: 'Terlalu sering memulai ronde, tunggu sebentar.' });
  }
  if (p.rid) await d.ref('rounds/' + p.rid).remove();
  const sn = (p.sn || []).slice(-150);
  const list = shuf(SPEC.map((_, i) => i).filter(i => !sn.includes(i))).slice(0, 10);
  const id = L.rid(10);
  await d.ref().update({
    ['rounds/' + id]: { pid, list, i: 0, life: 3, right: 0, pts: 0, st: 0, best: 0, qs: t, t0: t, ex: t + L.ROUND_TTL, tm: [0] },
    ['players/' + pid + '/rid']: id,
    ['players/' + pid + '/sn']: sn.concat(list).slice(-150)
  });
  res.json({ rid: id, i: 0, life: 3, q: mkq(id, 0, list[0]) });
}

async function answer(c, b, res) {
  const { pid, d } = c;
  const id = String(b.rid || '').replace(/[^a-f0-9]/g, '');
  if (!id) return res.status(400).json({ err: 'rid' });
  const t = Date.now();
  let out = null;
  await d.ref('rounds/' + id).transaction(cur => {
    out = null;
    if (cur === null) return null;
    if (cur.pid !== pid) return;
    if (t > cur.ex) { out = { exp: 1 }; return; }
    if (b.qi !== cur.i) { out = { dup: 1 }; return; }
    const si = cur.list[cur.i];
    const el = t - cur.qs;
    const lim = (WORD.includes(SPEC[si][1]) ? 30 : 15) * 1000 + 3000;
    const ok = el <= lim && correct(id, cur.i, si, b.v);
    cur.tm = (cur.tm || []).filter((x, k) => k > 0).concat([el]);
    cur.tm.unshift(0);
    if (ok) { cur.pts += 10; cur.right++; cur.st++; cur.best = Math.max(cur.best, cur.st); }
    else { cur.life--; cur.st = 0; }
    const ai = cur.i;
    cur.i++;
    cur.qs = t;
    out = {
      ok, si, ai, st: cur.st, pts: cur.pts, life: cur.life, i: cur.i, best: cur.best, right: cur.right,
      done: cur.i >= 10 || cur.life <= 0, nx: cur.list[cur.i], tm: cur.tm.slice(1), total: t - cur.t0
    };
    return cur;
  });
  if (!out) return res.status(404).json({ err: 'round', msg: 'Ronde tidak ditemukan.' });
  if (out.exp) { await d.ref('rounds/' + id).remove(); return res.status(410).json({ exp: 1, msg: 'Ronde kedaluwarsa, mulai lagi.' }); }
  if (out.dup) return res.status(409).json({ err: 'dup' });

  const full = out.right === 10 && out.life > 0;
  const why = bot(out.tm, out.total, full && out.done);
  if (why) {
    await d.ref('rounds/' + id).remove();
    const bn = await L.strike(c, 'AUTOPLAY', 2, why);
    if (bn) return L.deny(res, bn);
    return res.status(400).json({ flag: 1, msg: 'Aktivitas tidak wajar terdeteksi, ronde dibatalkan.' });
  }
  const sp = SPEC[out.si];
  const rev = out.ok ? null : (sp[1] === 'bs' ? (isTrue(id, out.ai) ? 'Benar' : 'Salah') : E[sp[0]].a);
  const r = { ok: out.ok, rev, st: out.st, pts: out.pts, life: out.life, i: out.i, best: out.best, right: out.right, done: out.done };
  if (!out.done) { r.q = mkq(id, out.i, out.nx); return res.json(r); }

  let np = null;
  await d.ref('players/' + pid).transaction(q => {
    if (q === null) return null;
    q.ok = (q.ok || 0) + out.right;
    q.best = Math.max(q.best || 0, out.best);
    if (full) { q.pts = (q.pts || 0) + 100; q.earn = (q.earn || 0) + 100; q.perf = (q.perf || 0) + 1; }
    q.rid = null;
    np = q;
    return q;
  });
  await d.ref('rounds/' + id).remove();
  r.full = full;
  r.total = np ? np.pts : 0;
  r.okAll = np ? np.ok : 0;
  r.bestAll = np ? np.best : 0;
  res.json(r);
}

module.exports = async (req, res) => {
  const c = await L.auth(req, res);
  if (!c) return;
  const b = req.body || {};
  if (b.a === 'start') return start(c, res);
  if (b.a === 'ans') return answer(c, b, res);
  res.status(400).json({ err: 'a' });
};
module.exports.mkq = mkq;
module.exports.isTrue = isTrue;
