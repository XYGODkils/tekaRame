const L = require('./_lib');

module.exports = async (req, res) => {
  if (!L.guard(req, res)) return;
  let c;
  try { c = await L.ctx(req, res); } catch (e) { console.error('ctx gagal:', e && e.message); return res.status(500).json({ err: 'server' }); }
  if (!c.ban) return res.status(400).json({ err: 'noban' });
  const b = c.ban;
  const ik = L.netKey(L.ipOf(req));
  if (await L.val('apidx/' + b.code)) return res.json({ ok: 1, dup: 1 });
  if (!(await L.rl('ap' + ik, 5, 3600000))) return res.status(429).json({ err: 'lim', msg: 'Terlalu banyak percobaan, coba lagi dalam 1 jam.' });
  const why = String((req.body && req.body.why) || '').trim().slice(0, 300);
  const d = L.db();
  const aid = 'a' + Date.now() + L.rid(2);
  let first = false;
  await d.ref('apidx/' + b.code).transaction(x => {
    first = false;
    if (x !== null) return;
    first = true;
    return aid;
  });
  if (!first) return res.json({ ok: 1, dup: 1 });
  await d.ref('appeals/' + aid).set({
    code: b.code, pid: b.pid, ip: L.ipOf(req), ipBan: b.ip, r: b.r, lbl: L.LABEL[b.r] || b.r,
    d: b.d || '', why, t: Date.now(), s: 'p'
  });
  const u = {};
  u['bans/pid/' + b.pid + '/ap'] = 1;
  if (b.ik) u['bans/ip/' + b.ik + '/ap'] = 1;
  await d.ref().update(u);
  await L.ev('appeal', { pid: b.pid, ip: L.ipOf(req), r: b.r, code: b.code });
  res.json({ ok: 1 });
};
