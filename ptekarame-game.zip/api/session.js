const L = require('./_lib');
const { SPEC } = require('./_data');

module.exports = async (req, res) => {
  const c = await L.auth(req, res, false);
  if (!c) return;
  const { p, pid, t } = c;
  const nav = (req.body && req.body.nav) || {};
  let warn = false;
  const direct = !c.fresh && nav.fresh && !nav.ref && !nav.sa && nav.nt === 'navigate' && t - (p.seen || 0) > 30 * 60 * 1000;
  if (process.env.ENTRY_GUARD !== 'off' && direct) {
    const w = p.wn && t - p.wn.t < L.ENTRY_WIN ? p.wn.n : 0;
    if (w >= 1) {
      const b = await L.ban(pid, c.ip, 'BOOKMARK', 'masuk langsung berulang dalam jendela peringatan', p.fp);
      return L.deny(res, b);
    }
    p.wn = { n: w + 1, t };
    await c.d.ref('players/' + pid + '/wn').set(p.wn);
    await L.ev('warn', { pid, ip: c.ip, r: 'BOOKMARK' });
    warn = true;
  }
  const upd = { seen: t, vpn: !!c.vpn };
  if (c.fp) upd.fp = c.fp;
  const cc = req.headers['x-vercel-ip-country'];
  if (cc) {
    if (p.cc && p.cc !== cc) { upd.ccc = t; await L.ev('ccchg', { pid, ip: c.ip, r: p.cc + ' ke ' + cc }); }
    upd.cc = cc;
  }
  await c.d.ref('players/' + pid).update(upd);
  res.json({
    k: L.mkKey(pid), t: L.mkTok(pid), pts: p.pts || 0, own: p.own || [0], bg: p.bg || 0, ok: p.ok || 0, best: p.best || 0,
    sq: SPEC.length, warn
  });
};
