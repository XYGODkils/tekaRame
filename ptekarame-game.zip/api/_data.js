const RAW={
Hewan:`KUCING|Hewan peliharaan yang mengeong|cat
ANJING|Sahabat manusia yang menggonggong|dog
IKAN|Hidup di air dan bernapas dengan insang|fish
KUDA|Hewan tunggangan yang berlari kencang|horse
BURUNG|Hewan berbulu yang bisa terbang|dove
LABALABA|Berkaki delapan dan menenun jaring|spider
KATAK|Melompat dan hidup di dua alam|frog
GAJAH|Bertelinga lebar dan berbelalai
JERAPAH|Hewan darat berleher paling panjang
HARIMAU|Kucing besar berloreng
SINGA|Raja hutan yang berambut surai
KELINCI|Bertelinga panjang dan suka wortel
ULAR|Melata tanpa kaki
BUAYA|Reptil bergigi tajam di sungai
KURAKURA|Bercangkang dan berjalan lambat
MONYET|Suka pisang dan memanjat pohon
BERUANG|Berbulu tebal dan suka madu
BADAK|Bercula di atas hidungnya
KAMBING|Mengembik dan berjenggot
SAPI|Penghasil susu segar
AYAM|Berkokok di pagi hari
BEBEK|Berkwek dan berjalan melenggok
LEBAH|Serangga penghasil madu
SEMUT|Kecil dan berbaris rapi
KUPUKUPU|Bersayap indah berasal dari ulat
HIU|Pemangsa laut bersirip punggung
PAUS|Mamalia laut terbesar
LUMBALUMBA|Mamalia laut yang pintar dan suka melompat
GURITA|Bertangan delapan di dasar laut
KEPITING|Berjalan menyamping dan bercapit
PENGUIN|Burung kutub yang tidak bisa terbang
ELANG|Pemburu bersayap tajam
BUNGLON|Bisa mengubah warna kulit
KANGURU|Melompat dan punya kantung
ZEBRA|Mirip kuda dengan belang hitam putih
MACAN|Kucing besar bertutul
RUSA|Bertanduk bercabang dan berlari gesit
TUPAI|Kecil dan lincah di pepohonan
CICAK|Merayap di dinding rumah
KELELAWAR|Mamalia yang terbang di malam hari`,
Benda:`MEJA|Tempat menaruh buku dan makanan
KURSI|Tempat duduk berkaki empat|chair
LEMARI|Tempat menyimpan pakaian
JAM|Penunjuk waktu|clock
PENSIL|Alat tulis yang bisa dihapus|pencil
BUKU|Berlembar-lembar dan dibaca|book
TAS|Tempat membawa barang ke sekolah
SEPATU|Dipakai di kaki saat berjalan
TOPI|Dipakai di kepala
PAYUNG|Pelindung dari hujan|umbrella
KUNCI|Pembuka gembok dan pintu|key
LAMPU|Pemberi cahaya di malam hari|lightbulb
KIPAS|Penghasil angin saat gerah|fan
CERMIN|Tempat melihat bayangan diri
GUNTING|Alat pemotong kertas|scissors
PALU|Alat pemukul paku|hammer
SENDOK|Alat makan untuk menyuap nasi|spoon
GARPU|Alat makan bergigi runcing
PISAU|Alat potong yang tajam
PIRING|Wadah nasi yang datar
GELAS|Wadah untuk minum|glass-water
PANCI|Wadah untuk merebus
KOMPOR|Sumber api untuk memasak
SAPU|Alat membersihkan lantai
EMBER|Wadah air bergagang
KASUR|Tempat tidur yang empuk|bed
BANTAL|Penyangga kepala saat tidur
SELIMUT|Penghangat badan saat tidur
KAMERA|Alat pengambil foto|camera
RADIO|Penyiar suara dan lagu|radio
TELEVISI|Layar tontonan di ruang keluarga|tv
KULKAS|Pendingin makanan
SETRIKA|Pelicin pakaian kusut
SIKAT|Pembersih gigi atau sepatu
HANDUK|Pengering badan usai mandi
SABUN|Pembersih badan berbusa
PENGHAPUS|Penghilang tulisan pensil
PENGGARIS|Pembuat garis lurus
BOLPOIN|Alat tulis bertinta
KALKULATOR|Alat hitung angka`,
Kota:`JAKARTA|Kota metropolitan dengan Monas
BANDUNG|Kota Kembang dengan Gedung Sate
SURABAYA|Kota Pahlawan
SEMARANG|Kota Lawang Sewu
MEDAN|Kota terbesar di Sumatera Utara
MAKASSAR|Kota Pantai Losari
PALEMBANG|Kota Jembatan Ampera
YOGYAKARTA|Kota pelajar dengan Malioboro
MALANG|Kota apel di Jawa Timur
BOGOR|Kota hujan dengan Kebun Raya
DEPOK|Kota di selatan Jakarta
BEKASI|Kota di timur Jakarta
TANGERANG|Kota di barat Jakarta
DENPASAR|Ibu kota Bali
MANADO|Ibu kota Sulawesi Utara
PONTIANAK|Kota di garis khatulistiwa
BANJARMASIN|Kota seribu sungai
BALIKPAPAN|Kota minyak di Kalimantan Timur
SAMARINDA|Ibu kota Kalimantan Timur
PADANG|Ibu kota Sumatera Barat
PEKANBARU|Ibu kota Riau
JAMBI|Ibu kota di tepi Sungai Batanghari
BENGKULU|Kota pesisir dengan Benteng Marlborough
KUPANG|Ibu kota Nusa Tenggara Timur
AMBON|Ibu kota Maluku
JAYAPURA|Ibu kota Papua
MATARAM|Ibu kota Nusa Tenggara Barat
SOLO|Kota batik dan Keraton Surakarta
CIREBON|Kota udang di pantai utara Jawa Barat
TEGAL|Kota asal warteg
MAGELANG|Kota dekat Candi Borobudur
KEDIRI|Kota tahu di Jawa Timur
BLITAR|Kota makam Bung Karno
MADIUN|Kota pecel di Jawa Timur
PASURUAN|Kota di jalur pantura Jawa Timur
SUKABUMI|Kota di Jawa Barat dekat Pelabuhan Ratu
SERANG|Ibu kota Banten
BATAM|Pulau industri dekat Singapura
TARAKAN|Kota pulau di Kalimantan Utara
PALU|Ibu kota Sulawesi Tengah
KENDARI|Ibu kota Sulawesi Tenggara`,
Daerah:`ACEH|Serambi Mekkah di ujung barat Indonesia
RIAU|Provinsi kaya minyak di tengah Sumatera
BANTEN|Provinsi di ujung barat Pulau Jawa
BALI|Pulau Dewata
LAMPUNG|Provinsi paling selatan Sumatera
GORONTALO|Provinsi di Sulawesi yang dulu bagian Sulawesi Utara
MALUKU|Kepulauan rempah-rempah
PAPUA|Pulau paling timur dengan burung cenderawasih
JAWABARAT|Provinsi tempat suku Sunda
JAWATENGAH|Provinsi di tengah Pulau Jawa
JAWATIMUR|Provinsi di ujung timur Pulau Jawa
SUMATERA|Pulau besar di barat Indonesia
KALIMANTAN|Pulau besar dengan hutan hujan dan suku Dayak
SULAWESI|Pulau berbentuk huruf K
LOMBOK|Pulau di sebelah timur Bali
FLORES|Pulau di Nusa Tenggara Timur
KOMODO|Pulau dan hewan kadal raksasa
SUMBA|Pulau dengan kuda dan kain tenun di NTT
TIMOR|Pulau yang dibagi dua negara
BUNAKEN|Taman laut terkenal di Sulawesi Utara
BROMO|Gunung berapi di Jawa Timur dengan lautan pasir
TORAJA|Daerah dengan rumah adat Tongkonan
MADURA|Pulau dengan karapan sapi
NIAS|Pulau tempat tradisi lompat batu
BELITUNG|Pulau dengan batu granit besar dan Laskar Pelangi
BANGKA|Pulau penghasil timah
HALMAHERA|Pulau terbesar di Maluku Utara
SERAM|Pulau besar di Maluku
BURU|Pulau di Maluku dekat Seram
KRAKATAU|Gunung berapi yang meletus dahsyat tahun 1883
MERAPI|Gunung api aktif dekat Yogyakarta
RINJANI|Gunung tertinggi di Lombok
SEMERU|Gunung tertinggi di Pulau Jawa
TOBA|Danau vulkanik terbesar di Sumatera Utara
BOROBUDUR|Candi Buddha terbesar di Magelang
PRAMBANAN|Candi Hindu megah dekat Yogyakarta
BATAK|Suku asal Sumatera Utara
MINANG|Suku dengan rumah gadang
SUNDA|Suku dari Jawa Barat dengan alat musik angklung`,
Makanan:`NASI|Makanan pokok dari beras
SATE|Daging tusuk yang dibakar
BAKSO|Bola daging berkuah
SOTO|Sup berkuah kuning khas Indonesia
RENDANG|Masakan daging khas Minang
GADOGADO|Sayuran dengan bumbu kacang
TEMPE|Olahan kedelai fermentasi
TAHU|Olahan kedelai berwarna putih
MIE|Makanan panjang yang digoreng atau direbus
ROTI|Dipanggang dari adonan tepung|bread-slice
KETUPAT|Nasi dalam anyaman daun kelapa
LONTONG|Nasi padat dibungkus daun pisang
OPOR|Masakan santan khas Lebaran
RAWON|Sup daging hitam khas Jawa Timur
PEMPEK|Makanan khas Palembang dengan cuko
GUDEG|Masakan nangka muda khas Yogyakarta
SEBLAK|Kerupuk berkuah pedas khas Bandung
BATAGOR|Singkatan dari bakso tahu goreng
SIOMAY|Dim sum dengan bumbu kacang
MARTABAK|Kue tebal manis atau telur
KLEPON|Kue hijau berisi gula merah
APEL|Buah merah yang dipetik di Malang|apple-whole
JERUK|Buah asam bulat berwarna oranye
MANGGA|Buah manis berwarna kuning
PISANG|Buah panjang kuning favorit monyet
NANAS|Buah berduri dengan mahkota daun
SEMANGKA|Buah hijau berdaging merah
DURIAN|Raja buah berduri dan berbau tajam
RAMBUTAN|Buah merah berbulu
SALAK|Buah bersisik seperti ular
MANGGIS|Ratu buah berkulit ungu
PEPAYA|Buah oranye yang baik untuk pencernaan
ANGGUR|Buah kecil bergerombol yang bisa jadi kismis
ALPUKAT|Buah hijau berdaging lembut untuk jus
KELAPA|Buah bersantan dan berair segar
TOMAT|Sayur buah merah untuk sambal
WORTEL|Akar oranye kesukaan kelinci|carrot
BAYAM|Sayuran hijau favorit Popeye
KENTANG|Umbi untuk kentang goreng
JAGUNG|Biji kuning dalam tongkol
TELUR|Dihasilkan ayam dan bisa direbus|egg`
};

const E=[];
Object.keys(RAW).forEach(cat=>RAW[cat].trim().split('\n').forEach(l=>{const p=l.split('|');E.push({a:p[0],c:p[1],ic:p[2]||'',cat})}));
const SPEC=[];
E.forEach((e,i)=>{['kata','susun','hilang','pilih','bs'].forEach(t=>SPEC.push([i,t]));if(e.ic)SPEC.push([i,'gambar'])});
const BG_P=[0,100,150,250,350,450,600];
const ITEMS=[{id:'wa100',p:1000},{id:'warand',p:750}];
module.exports={E,SPEC,BG_P,ITEMS};
