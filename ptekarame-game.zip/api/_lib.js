const admin = require('firebase-admin');
const crypto = require('crypto');

const SECRET = process.env.TR_SECRET || '';
const CHEAT_LIMIT = 500;
const DAY = 86400000;
const IP_COOL = 20 * 60 * 1000;
const ROUND_TTL = 15 * 60 * 1000;
const SUS = 24 * 3600 * 1000;
const ENTRY_WIN = 6 * 3600 * 1000;
const LABEL = {
  CHEAT_POINTS: 'Poin tidak wajar',
  AUTOPLAY: 'Pola auto play',
  TAMPER: 'Request dimanipulasi',
  BOOKMARK: 'Masuk lewat bookmark berulang',
  IP_ROTATE: 'IP berganti-ganti saat redeem',
  BRUTE: 'Menebak kode redeem',
  EVASION: 'Mencoba lolos dari ban',
  MANUAL: 'Ban manual dari owner'
};
const CHEAT = ['CHEAT_POINTS', 'AUTOPLAY', 'TAMPER', 'EVASION'];

function db() {
  if (!admin.apps.length) {
    const sa = JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT);
    if (sa.private_key) sa.private_key = sa.private_key.replace(/\\n/g, '\n');
    admin.initializeApp({ credential: admin.credential.cert(sa), databaseURL: process.env.FIREBASE_DB_URL });
  }
  return admin.database();
}

const val = async p => (await db().ref(p).once('value')).val();
const now = () => Date.now();
const sig = s => crypto.createHmac('sha256', SECRET).update(s).digest('base64url');
const eq = (a, b) => {
  const x = Buffer.from(String(a)), y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};
const rid = n => crypto.randomBytes(n).toString('hex');
const ikey = ip => String(ip || 'x').replace(/[^A-Za-z0-9]/g, '_');
const v6 = ip => {
  const a = String(ip).split('::');
  const h = a[0] ? a[0].split(':') : [], t = a[1] ? a[1].split(':') : [];
  const f = h.concat(Array(Math.max(0, 8 - h.length - t.length)).fill('0'), t);
  return f.slice(0, 4).map(x => x.padStart(4, '0')).join(':');
};
const netKey = ip => (String(ip || '').includes(':') ? 'v6_' + ikey(v6(ip)) : ikey(ip));
const offOf = (tz, t) => {
  try {
    const v = new Intl.DateTimeFormat('en-US', { timeZone: tz, timeZoneName: 'shortOffset' })
      .formatToParts(new Date(t)).find(x => x.type === 'timeZoneName').value;
    const m = v.match(/GMT([+-])(\d+)(?::(\d+))?/);
    if (!m) return 0;
    return (m[1] === '-' ? -1 : 1) * (Number(m[2]) * 60 + Number(m[3] || 0));
  } catch (e) { return null; }
};
const vpnSig = (req, nav) => {
  const tz = req.headers['x-vercel-ip-timezone'];
  if (!tz || typeof nav.off !== 'number') return false;
  const o = offOf(decodeURIComponent(tz), now());
  return o !== null && Math.abs(o - nav.off) >= 60;
};
const ipOf = req => String(
  req.headers['x-vercel-forwarded-for'] || req.headers['x-real-ip'] || req.headers['x-forwarded-for'] ||
  (req.socket && req.socket.remoteAddress) || ''
).split(',')[0].trim();

const cookies = req => {
  const o = {};
  String(req.headers.cookie || '').split(';').forEach(s => {
    const i = s.indexOf('=');
    if (i > 0) o[s.slice(0, i).trim()] = s.slice(i + 1).trim();
  });
  return o;
};
const setCookie = (res, n, v, age) =>
  res.setHeader('Set-Cookie', `${n}=${v}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=${age}`);

const mkTok = pid => {
  const t = pid + '.' + now();
  return t + '.' + sig('c.' + t);
};
const readTok = tok => {
  const a = String(tok || '').split('.');
  if (a.length !== 3) return null;
  return eq(a[2], sig('c.' + a[0] + '.' + a[1])) ? a[0] : null;
};
const mkKey = pid => {
  const t = pid + '.' + now();
  return t + '.' + sig('k.' + t);
};
const chkKey = (req, pid) => {
  const a = String(req.headers['x-tr'] || '').split('.');
  if (a.length !== 3) return 'bad';
  if (!eq(a[2], sig('k.' + a[0] + '.' + a[1])) || a[0] !== pid) return 'bad';
  return now() - Number(a[1]) < 12 * 3600 * 1000 ? 'ok' : 'old';
};

function guard(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  if (req.method !== 'POST') { res.status(405).json({ err: 'method' }); return false; }
  const o = req.headers.origin || '';
  let host = '';
  try { host = new URL(o).host; } catch (e) {}
  const allow = (process.env.ALLOW_ORIGINS || '').split(',').filter(Boolean);
  const sf = req.headers['sec-fetch-site'];
  if (!host || (host !== req.headers.host && !allow.includes(o)) || (sf && sf !== 'same-origin')) {
    res.status(403).json({ err: 'origin' });
    return false;
  }
  if (!String(req.headers['content-type'] || '').includes('application/json')) {
    res.status(415).json({ err: 'type' });
    return false;
  }
  return true;
}

async function rl(key, max, win) {
  let hit = false;
  await db().ref('rl/' + key).transaction(c => {
    hit = false;
    const t = now();
    if (c === null || t - c.t > win) return { n: 1, t };
    if (c.n >= max) { hit = true; return; }
    c.n++;
    return c;
  });
  return !hit;
}

async function ev(k, o) {
  try { await db().ref('ev').push(Object.assign({ k, t: now() }, o)); } catch (e) {}
}

async function ban(pid, ip, r, d, fp) {
  const b = { code: 'BN-' + rid(3).toUpperCase(), r, pid, ip, ik: netKey(ip), t: now(), d: String(d || '').slice(0, 200), ap: 0 };
  const u = {};
  u['bans/pid/' + pid] = b;
  u['bans/ip/' + b.ik] = b;
  u['bc/' + b.code + '/pids/' + pid] = true;
  u['bc/' + b.code + '/iks/' + b.ik] = true;
  if (fp) { u['bans/fp/' + fp] = b; u['bc/' + b.code + '/fps/' + fp] = true; }
  await db().ref().update(u);
  await ev('ban', { pid, ip, r, d: b.d, code: b.code });
  return b;
}

const banOut = b => ({ code: b.code, label: LABEL[b.r] || b.r, cheat: CHEAT.includes(b.r), ap: b.ap || 0 });
const deny = (res, b) => res.status(403).json({ ban: banOut(b) });
const expected = p => (p.earn || 0) + (p.red || 0) - (p.spent || 0);

async function strike(c, r, w, d) {
  const t = now();
  const sk = (c.p.sk || []).filter(x => t - x.t < DAY);
  for (let i = 0; i < (w || 1); i++) sk.push({ t, r });
  c.p.sk = sk;
  await db().ref('players/' + c.pid + '/sk').set(sk);
  await ev('strike', { pid: c.pid, ip: c.ip, r, d: d || '' });
  if (sk.length >= 3) return ban(c.pid, c.ip, r, 'strike x' + sk.length + ' ' + (d || ''), c.p.fp);
  return null;
}

async function ctx(req, res, create) {
  const ip = ipOf(req), ik = netKey(ip), t = now(), d = db();
  const nav = (req.body && req.body.nav) || {};
  const fp = /^[a-f0-9]{16,64}$/.test(String(nav.fp || '')) ? nav.fp : '';
  const ck = readTok(cookies(req).tr_id);
  let pid = ck || readTok(req.headers['x-tr-id']), fresh = false;
  const rd = await Promise.all([
    val('bans/ip/' + ik),
    pid ? val('players/' + pid) : null,
    pid ? val('bans/pid/' + pid) : null,
    fp ? val('bans/fp/' + fp) : null
  ]);
  const ib = rd[0], fh = rd[3];
  let p = rd[1], pb = rd[2];
  const vpn = vpnSig(req, nav);
  if (!p) {
    pb = null;
    if (ib) return { ban: ib };
    if (!create) return { need: true };
    if (!(await rl('nd' + ik, 4, DAY))) return { lim: true };
    pid = rid(12);
    fresh = true;
    p = { c: t, seen: t, pts: 0, own: [0], bg: 0, ok: 0, best: 0, earn: 0, red: 0, spent: 0, perf: 0, ip, ipc: 0, ipl: { [ik]: t }, fp, vpn };
    if (fh && !vpn) { p.susu = t + SUS; await ev('sus', { pid, ip, r: 'fingerprint cocok dengan perangkat yang di-ban', code: fh.code }); }
    await d.ref('players/' + pid).set(p);
    setCookie(res, 'tr_id', mkTok(pid), 31536000);
    if (fh && vpn) {
      const nb = Object.assign({}, fh, { pid });
      const u = {};
      u['bans/pid/' + pid] = nb;
      u['bc/' + fh.code + '/pids/' + pid] = true;
      await d.ref().update(u);
      await ev('evasion', { pid, ip, r: 'EVASION', code: fh.code, d: 'fingerprint cocok dan lokasi IP tidak sesuai perangkat' });
      return { ban: nb };
    }
  } else if (!ck) {
    setCookie(res, 'tr_id', mkTok(pid), 31536000);
  }
  const c = { d, pid, ip, ik, p, fresh, t, fp, vpn };
  const b = pb || ib;
  if (b) {
    const u = {};
    if (!pb) { u['bans/pid/' + pid] = Object.assign({}, b, { pid }); u['bc/' + b.code + '/pids/' + pid] = true; }
    if (!ib) { u['bans/ip/' + ik] = Object.assign({}, b, { ip, ik }); u['bc/' + b.code + '/iks/' + ik] = true; }
    if (Object.keys(u).length) await d.ref().update(u);
    return { ban: b };
  }
  if (p.ip !== ip) {
    const ipl = p.ipl || {};
    ipl[ik] = t;
    const n = {};
    Object.keys(ipl).sort((a, b2) => ipl[b2] - ipl[a]).slice(0, 8).forEach(k => { n[k] = ipl[k]; });
    p.ipl = n; p.ipc = t; p.ip = ip;
    await d.ref('players/' + pid).update({ ip, ipc: t, ipl: n });
  }
  if ((p.pts || 0) - expected(p) > CHEAT_LIMIT || (p.earn || 0) > (p.perf || 0) * 100) {
    const bb = await ban(pid, ip, 'CHEAT_POINTS',
      `pts=${p.pts} seharusnya=${expected(p)} ronde=${p.perf || 0} redeem=${p.red || 0}`, p.fp);
    return { ban: bb };
  }
  return c;
}

async function auth(req, res, needKey) {
  if (!guard(req, res)) return null;
  let c;
  try { c = await ctx(req, res, needKey === false); } catch (e) { console.error('ctx gagal:', e && e.message); res.status(500).json({ err: 'server' }); return null; }
  if (c.lim) { res.status(429).json({ err: 'lim', msg: 'Terlalu banyak perangkat baru dari jaringan ini.' }); return null; }
  if (c.ban) { deny(res, c.ban); return null; }
  if (c.need) { res.status(401).json({ need: 1 }); return null; }
  if (needKey !== false) {
    const k = chkKey(req, c.pid);
    if (k === 'bad') {
      const b = await strike(c, 'TAMPER', 3, 'kunci sesi tidak valid');
      if (b) deny(res, b); else res.status(401).json({ need: 1 });
      return null;
    }
    if (k === 'old') { res.status(401).json({ need: 1 }); return null; }
  }
  return c;
}

module.exports = {
  db, val, now, rid, ikey, netKey, ipOf, sig, eq, guard, rl, ev, ban, banOut, deny, strike, ctx, auth, mkKey, mkTok,
  expected, SUS, LABEL, CHEAT_LIMIT, DAY, IP_COOL, ROUND_TTL, ENTRY_WIN
};
