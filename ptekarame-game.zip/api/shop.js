const L = require('./_lib');
const { BG_P, ITEMS } = require('./_data');

const WA = /^https:\/\/(www\.)?whatsapp\.com\/channel\/[A-Za-z0-9_-]{6,60}\/?$/i;

module.exports = async (req, res) => {
  const c = await L.auth(req, res);
  if (!c) return;
  const { pid, ip, d, t } = c;
  const b = req.body || {};

  if (b.a === 'bg') {
    const i = Math.floor(Number(b.i));
    if (!(i >= 0 && i < BG_P.length)) return res.status(400).json({ err: 'i' });
    let st = 0, np = null;
    await d.ref('players/' + pid).transaction(q => {
      if (q === null) return null;
      st = 0;
      const own = q.own || [0];
      if (!own.includes(i)) {
        if ((q.pts || 0) < BG_P[i]) { st = 1; return; }
        q.pts -= BG_P[i];
        q.spent = (q.spent || 0) + BG_P[i];
        own.push(i);
        q.own = own;
      }
      q.bg = i;
      np = q;
      return q;
    });
    if (st === 1) {
      const bn = await L.strike(c, 'TAMPER', 1, 'beli background tanpa poin cukup');
      if (bn) return L.deny(res, bn);
      return res.json({ err: 1, msg: 'Poin belum cukup' });
    }
    return res.json({ ok: 1, pts: np.pts, own: np.own, bg: np.bg });
  }

  if (b.a === 'wa') {
    const it = ITEMS[Math.floor(Number(b.i))];
    const l = String(b.l || '').trim();
    if (!it) return res.status(400).json({ err: 'i' });
    if (!WA.test(l)) return res.json({ err: 1, msg: 'Masukkan link saluran WhatsApp yang benar' });
    if (c.p.susu && t < c.p.susu) return res.json({ err: 1, msg: 'Perangkat ini sedang diverifikasi, coba lagi nanti.' });
    if (!(await L.rl('ro' + pid, 5, L.DAY))) return res.json({ err: 1, msg: 'Batas pesanan harian tercapai' });
    const oid = 'o' + t + L.rid(2);
    await d.ref('orders/' + oid).set({ i: it.id, l, t, pid, ip, p: it.p });
    let st = 0, np = null;
    await d.ref('players/' + pid).transaction(q => {
      if (q === null) return null;
      st = 0;
      if ((q.pts || 0) < it.p) { st = 1; return; }
      q.pts -= it.p;
      q.spent = (q.spent || 0) + it.p;
      np = q;
      return q;
    });
    if (st === 1) {
      await d.ref('orders/' + oid).remove();
      const bn = await L.strike(c, 'TAMPER', 1, 'pesan item tanpa poin cukup');
      if (bn) return L.deny(res, bn);
      return res.json({ err: 1, msg: 'Poin belum cukup' });
    }
    return res.json({ ok: 1, pts: np.pts });
  }
  res.status(400).json({ err: 'a' });
};
