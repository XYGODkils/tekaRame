const L = require('./_lib');

const cl = s => String(s || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 24);
const fail = (res, msg) => res.json({ err: 1, msg });

async function once(ref) {
  let ok = false;
  await ref.transaction(c => {
    ok = false;
    if (c !== null) return;
    ok = true;
    return { t: Date.now() };
  });
  return ok;
}

module.exports = async (req, res) => {
  const c = await L.auth(req, res);
  if (!c) return;
  const { pid, ip, ik, p, d, t } = c;
  const k = cl(req.body && req.body.code);
  if (!k) return fail(res, 'Masukkan kode dulu');

  if (!(await L.rl('rp' + pid, 10, 600000)) || !(await L.rl('ri' + ik, 25, 600000))) {
    const b = await L.strike(c, 'BRUTE', 1, 'percobaan redeem terlalu banyak');
    if (b) return L.deny(res, b);
    return fail(res, 'Terlalu banyak percobaan, tunggu beberapa menit.');
  }

  if (p.susu && t < p.susu) {
    const m = Math.ceil((p.susu - t) / 3600000);
    return fail(res, 'Perangkat ini sedang diverifikasi. Coba lagi sekitar ' + m + ' jam lagi.');
  }
  if (p.vpn || (p.ccc && t - p.ccc < L.IP_COOL)) {
    await L.ev('vpn', { pid, ip, r: 'redeem ditahan' });
    return fail(res, 'Terdeteksi VPN atau lokasi tidak sesuai. Matikan VPN, muat ulang halaman, lalu coba lagi.');
  }
  const ipl = p.ipl || {};
  const recent = Object.keys(ipl).filter(x => t - ipl[x] < L.DAY).length;
  if (recent >= 4) {
    const b = await L.ban(pid, ip, 'IP_ROTATE', 'IP berubah ' + recent + 'x dalam 24 jam saat redeem', p.fp);
    return L.deny(res, b);
  }
  if (p.ipc && t - p.ipc < L.IP_COOL) {
    const m = Math.ceil((L.IP_COOL - (t - p.ipc)) / 60000);
    await L.ev('ipchg', { pid, ip, r: 'redeem ditahan' });
    return fail(res, 'Jaringan baru saja berganti. Coba lagi sekitar ' + m + ' menit lagi.');
  }

  const code = await L.val('codes/' + k);
  if (!code || code.t === 'b') {
    if (!(await L.rl('rf' + pid, 8, 3600000))) {
      const b = await L.strike(c, 'BRUTE', 2, 'menebak kode redeem');
      if (b) return L.deny(res, b);
    }
    return fail(res, 'Kode tidak ditemukan');
  }

  const id = k + '_' + (code.v || 0);
  const pk = d.ref('used/' + id + '/p_' + pid), ikr = d.ref('used/' + id + '/i_' + ik);
  if (!(await once(pk))) return fail(res, 'Kode ini sudah dipakai');
  if (!(await once(ikr))) {
    await pk.remove();
    return fail(res, 'Kode ini sudah dipakai dari jaringan ini');
  }

  if (code.mx) {
    let okc = false;
    await d.ref('codes/' + k + '/u').transaction(u => {
      okc = false;
      if ((u || 0) >= code.mx) return;
      okc = true;
      return (u || 0) + 1;
    });
    if (!okc) {
      await pk.remove();
      await ikr.remove();
      return fail(res, 'Kuota kode ini sudah habis');
    }
  }

  if (code.t === 'm') {
    await L.ev('redeem', { pid, ip, r: k, d: 'pesan' });
    return res.json({ ok: 1, t: 'm', x: String(code.x || '') });
  }

  const n = Math.max(0, Math.floor(Number(code.n) || 0));
  let np = null;
  await d.ref('players/' + pid).transaction(q => {
    if (q === null) return null;
    q.pts = (q.pts || 0) + n;
    q.red = (q.red || 0) + n;
    np = q;
    return q;
  });
  await L.ev('redeem', { pid, ip, r: k, d: '+' + n });
  res.json({ ok: 1, t: 'p', n, pts: np ? np.pts : 0 });
};
