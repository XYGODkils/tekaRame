TekaRame v2 (game publik)

Isi: index.html, style.css, app.js (klien), folder api/ (backend serverless), database.rules.json.
Semua poin, ronde, redeem, ban, dan cek IP dijalankan di folder api/. Klien tidak lagi menyimpan poin.

1. Firebase baru
   - Buat project Firebase baru, aktifkan Realtime Database.
   - Tab Rules: tempel isi database.rules.json lalu Publish (semua akses klien ditutup).
   - Project settings, Service accounts, Generate new private key. Isi file JSON itu dipakai di langkah 2.
   - Project Firebase lama: ubah Rules jadi false semua atau hapus databasenya, karena isinya sudah bocor.

2. Environment variables di Vercel (Settings, Environment Variables)
   FIREBASE_SERVICE_ACCOUNT = isi JSON service account (tempel satu baris)
   FIREBASE_DB_URL          = URL Realtime Database baru
   TR_SECRET                = teks acak panjang (minimal 32 karakter)
   ENTRY_GUARD              = off (opsional, untuk mematikan deteksi masuk lewat bookmark)
   ALLOW_ORIGINS            = opsional, domain tambahan, pisahkan dengan koma

3. Deploy
   Upload folder ini lewat GitHub lalu Import di Vercel, atau pakai Vercel CLI. Setelah env diisi, Redeploy.
   Vercel akan memasang firebase-admin otomatis dari package.json.

Aturan keamanan yang aktif
   - Poin hanya berubah lewat server (ronde sempurna 100 poin, kode redeem, belanja).
   - Audit poin: jika poin melebihi riwayat ronde dan redeem lebih dari 500, IP dan perangkat langsung di-ban.
   - Auto play: jawaban terlalu cepat, interval seragam, ronde selesai terlalu cepat, atau ronde dimulai terlalu sering menghasilkan strike. Strike kedaluwarsa 24 jam, 3 strike berarti ban. Ronde kedaluwarsa 15 menit.
   - Masuk lewat bookmark atau alamat langsung: peringatan pertama, pelanggaran lagi dalam 6 jam di-ban.
   - IP berganti: redeem ditahan 20 menit setelah IP berubah, dan 4 IP berbeda dalam 24 jam saat redeem berarti ban.
   - Layar ban menampilkan kode ban dan tombol ajukan. Pengajuan muncul di owner panel.
   - Ban lolos: ban tercatat pada IP (IPv6 per jaringan /64), cookie, token cadangan di penyimpanan browser, dan sidik perangkat. Perangkat baru dengan sidik sama dan lokasi IP tidak sesuai jam perangkat (tanda VPN) langsung terhubung ke ban lama. Tanpa VPN, perangkat itu dicurigai 24 jam (tidak bisa redeem dan pesan WA).
   - VPN atau lokasi berubah: redeem ditahan sampai VPN dimatikan dan halaman dimuat ulang.
   - Pengajuan ban: satu pengajuan per kode ban, batas percobaan 5 per jam per jaringan dan otomatis reset.
